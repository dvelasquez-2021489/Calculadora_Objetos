/*
    Nombre: Darien Damery Velásquez Vielman
    Código Técnico: IN5AV
    Carné: 2021489
    Fecha de Creación: 23/03/2021
    Fecha de Modificaciones: 10/04/2022
 */
package org.darienvelasquez.system;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class FXMLDocumentController implements Initializable {
    double dato1, dato2, result = 0, contador = 0;
    @FXML private Button btnMasMenos;
    @FXML private Button btnCero;
    @FXML private Button btnPunto;
    @FXML private Button btnIgual;
    @FXML private Button btnUno;
    @FXML private Button btnDos;
    @FXML private Button btnTres;
    @FXML private Button btnMas;
    @FXML private Button btnCuatro;
    @FXML private Button btnCinco;
    @FXML private Button btnSeis;
    @FXML private Button btnMenos;
    @FXML private Button btnSiete;
    @FXML private Button btnOcho;
    @FXML private Button btnNueve;
    @FXML private Button btnMulti;
    @FXML private Button btnUnoX;
    @FXML private Button btnCuadrado;
    @FXML private Button btnRaiz;
    @FXML private Button btnDivi;
    @FXML private Button btnPorcentaje;
    @FXML private Button btnCE;
    @FXML private Button btnC;
    @FXML private TextField txtPantalla;
    private char opr;
    private double acumulado;
    private boolean in = true;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        if (event.getSource() == btnCero){
            if (in == true)
                txtPantalla.setText(txtPantalla.getText()+"0");
            else
                txtPantalla.setText("0");
                in = true;
            
        }else if (event.getSource() == btnUno){
            if (in == true)
                txtPantalla.setText(txtPantalla.getText()+"1");
            else
                txtPantalla.setText("1");
                in = true;
            
        }else if (event.getSource() == btnDos){
            if (in == true)
                txtPantalla.setText(txtPantalla.getText()+"2");
            else
                txtPantalla.setText("2");
                in= true;
            
        }else if(event.getSource() == btnPunto){
            if (txtPantalla.getText().length() == 0){
                txtPantalla.setText("0.");
                btnPunto.setDisable(true);
            }else{
                txtPantalla.setText(txtPantalla.getText()+".");
                btnPunto.setDisable(true);
            }
        
        }else if (event.getSource() == btnTres){
            if (in == true)
                txtPantalla.setText(txtPantalla.getText()+"3");
            else
                txtPantalla.setText("3");
                in = true;
             
        }else if(event.getSource() == btnCuatro){
            if (in == true)
                txtPantalla.setText(txtPantalla.getText()+"4");
            else
                txtPantalla.setText("4");
                in = true;
            
        }else if(event.getSource() == btnCinco){
            if (in == true)
                txtPantalla.setText(txtPantalla.getText()+"5");
            else
                txtPantalla.setText("5");
                in = true;
            
        }else if(event.getSource() == btnSeis){
            if (in == true)
                txtPantalla.setText(txtPantalla.getText()+"6");
            else
                txtPantalla.setText("6");
                in = true;
            
        }else if(event.getSource() == btnSiete){
            if (in == true)
                txtPantalla.setText(txtPantalla.getText()+"7");
            else 
                txtPantalla.setText("7");
                in = true;
            
        }else if(event.getSource() == btnOcho){
            if (in == true)
                txtPantalla.setText(txtPantalla.getText()+"8");
            else
                txtPantalla.setText("8");
                in = true;
            
        }else if(event.getSource() == btnNueve)
            if (in == true)
                txtPantalla.setText(txtPantalla.getText()+"9");
            else
                txtPantalla.setText("9");
                in = true;
        
// botones de operaciones        
        if (event.getSource() == btnMas){
            if (contador == 0){
                dato1 = Double.parseDouble(txtPantalla.getText());
                txtPantalla.clear();
            }else{
                if (contador == 1){
                    acumulado = dato1 + Double.parseDouble(txtPantalla.getText());
                    txtPantalla.setText(String.valueOf(acumulado));
                }else if (contador > 1)
                    acumulado = acumulado + Double.parseDouble(txtPantalla.getText());
                    txtPantalla.setText(String.valueOf(acumulado));
            }
            opr = '+';
            btnPunto.setDisable(false);
            contador = contador + 1;
            in = false;

        }else if (event.getSource() == btnIgual){
            contador = contador + 1;
            dato2 = Double.parseDouble(txtPantalla.getText());
            if(acumulado > 0){
                dato1 = acumulado;
            }
            if(opr == '+'){
                result = dato1 + dato2;
                txtPantalla.setText(String.valueOf(result));
            }
            if(opr == '-'){
                result = dato1 - dato2;
                txtPantalla.setText(String.valueOf(result));
            }
            if(opr == '*'){
                result = dato1 * dato2;
                txtPantalla.setText(String.valueOf(result));
            }
            if(opr == '/'){
                result = dato1 / dato2;
                txtPantalla.setText(String.valueOf(result));
            }            
            
        }else if (event.getSource() == btnMenos){            
            if (contador == 0){
                dato1 = Double.parseDouble(txtPantalla.getText());
                txtPantalla.clear();
            }else{
                if (contador == 1){
                    acumulado = dato1 - Double.parseDouble(txtPantalla.getText());
                    txtPantalla.setText(String.valueOf(acumulado));
                }else if (contador > 1)
                    acumulado = acumulado - Double.parseDouble(txtPantalla.getText());
                    txtPantalla.setText(String.valueOf(acumulado));
            }
            opr = '-';
            btnPunto.setDisable(false);
            contador = contador + 1;
            in = false;
   
       
        }else if (event.getSource() == btnMulti){
            if (contador == 0){
                dato1 = Double.parseDouble(txtPantalla.getText());
                txtPantalla.clear();
            }else{
                if (contador == 1){
                    acumulado = dato1 * Double.parseDouble(txtPantalla.getText());
                    txtPantalla.setText(String.valueOf(acumulado));
                }else if (contador > 1)
                    acumulado = acumulado * Double.parseDouble(txtPantalla.getText());
                    txtPantalla.setText(String.valueOf(acumulado));
            }
            opr = '*';
            btnPunto.setDisable(false);
            contador = contador + 1;
            in = false;
                    
        }else if (event.getSource() == btnDivi){
           if (contador == 0){
                dato1 = Double.parseDouble(txtPantalla.getText());
                txtPantalla.clear();
            }else{
                if (contador == 1){
                    acumulado = dato1 / Double.parseDouble(txtPantalla.getText());
                    txtPantalla.setText(String.valueOf(acumulado));
                }else if (contador > 1)
                    acumulado = acumulado / Double.parseDouble(txtPantalla.getText());
                    txtPantalla.setText(String.valueOf(acumulado));
            
           }
            opr = '/';
            btnPunto.setDisable(false);
            contador = contador + 1;
            in = false;
                    

        }else if (event.getSource() == btnCuadrado){
            dato1 = Double.parseDouble(txtPantalla.getText());
            double cuadrado = 2;
            result = Math.pow(dato1, cuadrado);
            txtPantalla.setText(String.valueOf(result));
            in = false;
            
        }else if (event.getSource() == btnRaiz){
            dato1 = Double.parseDouble(txtPantalla.getText());
            result = Math.sqrt(dato1);
            txtPantalla.setText(String.valueOf(result));
            in = false;
            
        }else if (event.getSource() == btnPorcentaje){
            double valPantalla, valPorcentaje;
            valPantalla = Double.parseDouble(txtPantalla.getText());
            txtPantalla.clear();
            valPorcentaje = dato1 * valPantalla / 100;
            txtPantalla.setText(String.valueOf(valPorcentaje));
            in = false;
            
        }else if (event.getSource() == btnMasMenos){
            dato1 = Double.parseDouble(txtPantalla.getText());
            dato1 = dato1 * -1;
            txtPantalla.setText(String.valueOf(dato1));
            in = false;
            
        } else if (event.getSource() == btnUnoX){
            dato1 = Double.parseDouble(txtPantalla.getText());
            txtPantalla.clear();
            result = 1/dato1;
            txtPantalla.setText(String.valueOf(result));
            in = false;
            
        }else if (event.getSource() == btnCE){
            txtPantalla.clear();
        
        }else if (event.getSource() == btnC){ 
            dato1 = 0;
            dato2 = 0;
            contador = 0;
            acumulado = 0;
            result = 0;
            txtPantalla.clear();
            btnPunto.setDisable(false);
        }
    }
    
        
    @Override
    public void initialize (URL url, ResourceBundle rb){
        //TODO
    }
}
